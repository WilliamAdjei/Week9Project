import './App.css';
import QuizPage from './quizPage';
import HomePage from './homepage';
import LEARNINGPAGE from './learningpage';
import ProductPage from './productPage';






function App() {
  return (
    <div className="App">
      
      {/* <HomePage></HomePage> */}
      {/* <LEARNINGPAGE></LEARNINGPAGE> */}
     <ProductPage></ProductPage>
     {/* <QuizPage></QuizPage> */}
     
      
    </div>
  );
}

export default App;

